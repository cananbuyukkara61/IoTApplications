# train-yolov8-object-detector-google-drive-colab

<p align="center">
<a href="https://www.youtube.com/watch?v=bx52WmQvbaE">
    <img width="1280" src="https://utils-computervisiondeveloper.s3.amazonaws.com/thumbnails/yolov8_object_detection_google_colab.jpg" alt="Watch the video">
    </br>Watch on YouTube: Train Yolo V8 object detector on your custom data | Google Colab | Step by step guide !
</a>
</p>

## dataset

If you want to use the same dataset I used in the video, [here](https://www.patreon.com/posts/how-to-download-91285241) are some instructions on how you can download an object detection dataset from the [Open Images Dataset v7](https://storage.googleapis.com/openimages/web/index.html).
